import express, { json } from "express";
import cors from "cors";
import "dotenv/config";

import { buildEnvelope, publishEnvelope, startConsumer } from "./servicebus.js";

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:3000" }));
app.use(json());

// ------------------------------------------------------------
// DADOS MOCK (fonte atual do BFF)
// ------------------------------------------------------------
function getMockParadas() {
  return {
    items: [
      {
        paradaId: 38,
        sigla: "PDP",
        embarcacao: "P. Paredes",
        coletores: [100],
        escopo: "Mob+PE+Man+DD",
        inicioRP: "30/09/25",
        terminoRP: "12/01/26",
        deltaInicio: 1,
        durRP: 105,
        durOrc: 92,
        deltaDurOrc: 13,
        durPlan: 120,
        fel: "FEL-3",
        statusParada: "Concluida",
        heroImageKey: "parcel-das-paredes"
      },
      {
        paradaId: 82,
        sigla: "PDT",
        embarcacao: "P. Timbebas",
        coletores: [100],
        escopo: "Mob+PE+Man+DD",
        inicioRP: "06/11/25",
        terminoRP: "09/02/26",
        deltaInicio: 36,
        durRP: 96,
        durOrc: 92,
        deltaDurOrc: 4,
        durPlan: 96,
        fel: "FEL-3",
        statusParada: "Execucao",
        heroImageKey: "parcel-das-timbebas"
      },
      {
        paradaId: 160,
        sigla: "PDR",
        embarcacao: "P. Reis",
        coletores: [100, 103],
        escopo: "Mob+Man",
        inicioRP: "24/11/25",
        terminoRP: "12/01/26",
        deltaInicio: 0,
        durRP: 50,
        durOrc: null,
        deltaDurOrc: null,
        durPlan: 48,
        fel: "FEL-3",
        statusParada: "Concluida",
        heroImageKey: "parcel-dos-reis"
      },
      {
        paradaId: 83,
        sigla: "PDB",
        embarcacao: "P. Bandolim",
        coletores: [100],
        escopo: "Mob+PE+Man+DD",
        inicioRP: "12/12/25",
        terminoRP: "25/02/26",
        deltaInicio: 0,
        durRP: 76,
        durOrc: null,
        deltaDurOrc: null,
        durPlan: 76,
        fel: "FEL-3",
        statusParada: "Execucao",
        heroImageKey: "parcel-do-bandolim"
      },
      {
        paradaId: 259,
        sigla: "RPA",
        embarcacao: "R. São Paulo",
        coletores: [100],
        escopo: "Mob",
        inicioRP: "27/12/25",
        terminoRP: "18/01/26",
        deltaInicio: 0,
        durRP: 23,
        durOrc: null,
        deltaDurOrc: null,
        durPlan: 23,
        fel: "FEL-3",
        statusParada: "Concluida",
        heroImageKey: "rochedo-de-sao-paulo"
      },
      {
        paradaId: 33,
        sigla: "PDM",
        embarcacao: "P. Meros",
        coletores: [100],
        escopo: "Mob+PE+Man+DD",
        inicioRP: "15/01/26",
        terminoRP: "05/04/26",
        deltaInicio: 442,
        durRP: 81,
        durOrc: 19,
        deltaDurOrc: 62,
        durPlan: 81,
        fel: "FEL-2",
        statusParada: "Execucao",
        heroImageKey: "parcel-dos-meros"
      },
      {
        paradaId: 207,
        sigla: "RPE",
        embarcacao: "R. São Pedro",
        coletores: [100, 103],
        escopo: "Mob+Man",
        inicioRP: "19/01/26",
        terminoRP: "15/02/26",
        deltaInicio: 0,
        durRP: 28,
        durOrc: null,
        deltaDurOrc: null,
        durPlan: 28,
        fel: "FEL-2",
        statusParada: "Execucao",
        heroImageKey: "rochedo-sao-pedro"
      },
      {
        paradaId: 260,
        sigla: "PFT",
        embarcacao: "P. Feiticeiras",
        coletores: [102],
        escopo: "UWS",
        inicioRP: "28/01/26",
        terminoRP: "01/02/26",
        deltaInicio: 0,
        durRP: 5,
        durOrc: null,
        deltaDurOrc: null,
        durPlan: 5,
        fel: "FEL-2",
        statusParada: "Backlog",
        heroImageKey: "parcel-das-feiticeiras"
      }
    ]
  };
}

// ------------------------------------------------------------
// CACHE (DEV): último payload consumido da fila
// ------------------------------------------------------------
let lastParadasFromQueue = null;
let lastParadasMeta = null;

app.get("/health", (req, res) => res.json({ ok: true }));

// Se já consumimos algo da fila, devolve isso; senão devolve o mock local.
app.get("/bff/paradas", (req, res) => {
  const fromQueue = !!lastParadasFromQueue;

  const data = fromQueue ? lastParadasFromQueue : getMockParadas();

  return res.json({
    meta: {
      source: fromQueue ? "servicebus" : "mock",
      lastConsumed: lastParadasMeta || null
    },
    ...data
  });
});


app.get("/bff/updates", (req, res) => {
  return res.json({
    groups: [
      {
        dateLabel: "26 de Novembro de 2025",
        items: [
          {
            title: "Serviço Atualizado",
            meta: "029 | A. Abrolhos | FEL-2",
            text: "Foi adicionado 2 materiais vinculados a linha de serviço.",
            user: "Daniel Santos",
            time: "11:15"
          },
          {
            title: "Parada Cancelada",
            meta: "033 | I. São sebastião | FEL 1",
            text: "Justificativa anexada",
            user: "Leonardo Silva",
            time: "09:09"
          }
        ]
      },
      {
        dateLabel: "25 de Novembro de 2025",
        items: [
          {
            title: "Nova GMUD aberta",
            meta: "026 | P. dos Reis | FEL-4",
            text: "Foi adicionado 2 materiais vinculados a linha de serviço.",
            user: "Guilherme Abreu",
            time: "11:15"
          }
        ]
      },
      {
        dateLabel: "Para mim",
        items: [
          {
            title: "Pendência atribuída",
            meta: "160 | P. dos Reis | FEL-4",
            text: "Você foi mencionado em uma atualização.",
            user: "Sistema",
            time: "08:40"
          }
        ]
      }
    ]
  });
});

// Publica o snapshot atual (mock) na fila SGO (DEV)
app.post("/bff/paradas/publish", async (req, res) => {
  try {
    const queueName = process.env.SB_QUEUE_SGO;
    const connStr = process.env.SB_SEND_CONNECTION_STRING;
    const producer = process.env.SB_PRODUCER || "HubBFF";
    if (!queueName) throw new Error("SB_QUEUE_SGO não configurada");
    if (!connStr) throw new Error("SB_SEND_CONNECTION_STRING não configurada");

    const payload = getMockParadas();
    const envelope = buildEnvelope({
      queueName,
      producer,
      schemaName: "ParadasSnapshot",
      schemaVersion: "1.0",
      payload
    });

    const ids = await publishEnvelope({ connectionString: connStr, queueName, envelope });
    return res.json({ ok: true, queueName, ...ids });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

// Endpoint de debug: retorna o último envelope consumido (meta + data)
app.get("/bff/paradas/last-consumed", (req, res) => {
  return res.json({ ok: true, meta: lastParadasMeta, data: lastParadasFromQueue });
});

// Consumer DEV: lê da fila SGO e atualiza cache
let consumerHandle = null;
function tryStartDevConsumer() {
  const connStr = process.env.SB_LISTEN_CONNECTION_STRING;
  const queueName = process.env.SB_QUEUE_SGO;

  // Se não configurou, segue sem consumer (front continuará usando mock local)
  if (!connStr || !queueName) {
    console.log("[SB] Consumer não iniciado (faltou SB_LISTEN_CONNECTION_STRING ou SB_QUEUE_SGO)");
    return;
  }

  const supportedSchemas = new Set(["ParadasSnapshot@1.0"]);
  consumerHandle = startConsumer({
    connectionString: connStr,
    queueName,
    supportedSchemas,
    onValidEnvelope: async (env, msg) => {
      lastParadasFromQueue = env.payload;
      lastParadasMeta = {
        messageId: msg.messageId,
        correlationId: msg.correlationId,
        deliveryCount: msg.deliveryCount,
        enqueuedTimeUtc: msg.enqueuedTimeUtc,
        occurredAt: env.occurredAt,
        producer: env.producer,
        schemaName: env.schemaName,
        schemaVersion: env.schemaVersion
      };
      console.log(`[SB] Consumed ${msg.messageId} (${env.schemaName}@${env.schemaVersion})`);
    },
    onError: (err) => console.error("[SB] Consumer error:", err)
  });

  console.log(`[SB] Consumer ativo na fila ${queueName}`);
}

const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`BFF on http://localhost:${port}`);
  tryStartDevConsumer();
});

process.on("SIGINT", async () => {
  if (consumerHandle?.stop) await consumerHandle.stop();
  process.exit(0);
});
