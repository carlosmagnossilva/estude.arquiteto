import { ServiceBusClient } from "@azure/service-bus";
import crypto from "crypto";

export function buildEnvelope({ queueName, producer, schemaName, schemaVersion, payload, correlationId }) {
  return {
    queueName,
    messageId: crypto.randomUUID(),
    correlationId: correlationId || crypto.randomUUID(),
    occurredAt: new Date().toISOString(),
    producer,
    schemaName,
    schemaVersion,
    payload
  };
}

export async function publishEnvelope({ connectionString, queueName, envelope }) {
  const sbClient = new ServiceBusClient(connectionString);
  const sender = sbClient.createSender(queueName);

  const message = {
    messageId: envelope.messageId,
    correlationId: envelope.correlationId,
    subject: envelope.schemaName,
    applicationProperties: {
      schemaVersion: envelope.schemaVersion,
      producer: envelope.producer
    },
    body: envelope
  };

  try {
    await sender.sendMessages(message);
    return { messageId: envelope.messageId, correlationId: envelope.correlationId };
  } finally {
    await sender.close();
    await sbClient.close();
  }
}

export function startConsumer({ connectionString, queueName, supportedSchemas, onValidEnvelope, onError }) {
  const sbClient = new ServiceBusClient(connectionString);
  const receiver = sbClient.createReceiver(queueName, { receiveMode: "peekLock" });

  const subscription = receiver.subscribe({
    processMessage: async (msg) => {
      const env = msg.body;
      const schemaKey = `${env?.schemaName || ""}@${env?.schemaVersion || ""}`;

      if (!supportedSchemas.has(schemaKey)) {
        await receiver.deadLetterMessage(msg, {
          deadLetterReason: "INVALID_SCHEMA",
          deadLetterErrorDescription: `Schema não suportado: ${schemaKey}`
        });
        return;
      }

      try {
        await onValidEnvelope(env, msg);
        await receiver.completeMessage(msg);
      } catch (e) {
        throw e;
      }
    },
    processError: async (args) => {
      if (onError) onError(args.error);
    }
  });

  async function stop() {
    try { await subscription.close(); } catch {}
    try { await receiver.close(); } catch {}
    try { await sbClient.close(); } catch {}
  }

  return { stop };
}
