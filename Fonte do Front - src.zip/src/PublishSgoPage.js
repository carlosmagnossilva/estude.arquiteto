import { useState } from "react";

export default function PublishSgoPage() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function onPublish() {
    setLoading(true);
    setStatus(null);

    try {
      const resp = await fetch("/bff/paradas/publish", { method: "POST" });
      const json = await resp.json();

      if (!resp.ok || !json.ok) {
        throw new Error(json.error || `HTTP ${resp.status}`);
      }

      setStatus({
        ok: true,
        message: "Publicado com sucesso na fila SGO.",
        data: json
      });
    } catch (e) {
      setStatus({ ok: false, message: e.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ marginTop: 0 }}>Publicar paradas na fila SGO</h2>

      <p style={{ maxWidth: 700 }}>
        Este botão chama o BFF para publicar o snapshot atual de <code>/bff/paradas</code> na fila
        configurada como SGO no Azure Service Bus.
      </p>

      <button
        type="button"
        onClick={onPublish}
        disabled={loading}
        style={{
          padding: "10px 14px",
          borderRadius: 10,
          border: 0,
          cursor: loading ? "not-allowed" : "pointer"
        }}
      >
        {loading ? "Publicando..." : "Publicar agora"}
      </button>

      {status && (
        <div
          style={{
            marginTop: 14,
            padding: 12,
            borderRadius: 10,
            border: "1px solid #CFE1E9",
            background: status.ok ? "#F0FDF4" : "#FEF2F2"
          }}
        >
          <div style={{ fontWeight: 800 }}>{status.message}</div>
          {status.ok && (
            <pre style={{ margin: "8px 0 0", whiteSpace: "pre-wrap" }}>
              {JSON.stringify(status.data, null, 2)}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}
